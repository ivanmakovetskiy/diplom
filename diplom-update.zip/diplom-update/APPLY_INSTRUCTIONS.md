# Как залить оформление в github.com/ivanmakovetskiy/diplom

GitHub-коннектор в Arena недоступен, поэтому изменения подготовлены локально.
Выбери **один** из двух способов — оба дают одинаковый результат.

---

## Способ 1 (самый простой): git bundle — 4 команды

Скачай файл `diplom-formatted.bundle` и выполни в своём клоне репозитория:

```bash
git fetch /path/to/diplom-formatted.bundle repo-format:repo-format
git checkout repo-format        # посмотри результат, покликай файлы
git checkout main
git merge --ff-only repo-format # перенести коммит оформления в main
git push origin main
```

Если хочешь, чтобы автором коммита был ты, после merge выполни:

```bash
git commit --amend --reset-author --no-edit
```

## Способ 2: zip со скриптом

```bash
# распаковать diplom-update.zip ВНУТРЬ своего клона репозитория и выполнить:
unzip diplom-update.zip
bash diplom-update/apply.sh            # применит и застейджит изменения
git diff --cached --stat               # проверь, что всё ок
git commit -m "Оформление репозитория: README (RU/EN), чистка артефактов сборки, CI для PDF"
git push origin main
```

---

## После пуша

1. **Actions** — при первом пуше запустится workflow *Build LaTeX documents* и соберёт
   `dissertation.pdf`, `synopsis.pdf`, `presentation.pdf` (скачиваются из артефактов запуска).
   ⚠️ В песочнице TeX Live не было, поэтому реальная сборка проверена только на уровне
   конфига: если CI упадёт на шрифтах — смотри лог шага Build; локально на Windows
   сборка как раньше (`make dissertation`), в CI используется `FONTFAMILY=2` (Liberation).

2. **Релиз с PDF** (по желанию):
   ```bash
   git tag v1.0-defended-2024
   git push origin v1.0-defended-2024   # workflow сам прикрепит PDF к Release
   ```

3. **Блок About на GitHub** (описание + теги; вручную на сайте или через GitHub CLI):
   ```bash
   gh repo edit ivanmakovetskiy/diplom \
     --description "Master's thesis (MISIS, 2024): empathy & emotions in LLMs in game-theoretic decision-making · LaTeX (XeLaTeX+Biber)" \
     --add-topic latex,masters-thesis,llm,large-language-models,game-theory,empathy,ai-alignment,decision-making,misis,xelatex
   ```

## Важно знать

- Удаление PDF в новом коммите **не уменьшает историю git** — старые версии файлов
  остаются в предыдущих коммитах. Это нормально. Если захочешь вычистить историю
  полностью — это делается через `git filter-repo` с force-push (опасно, ломает
  чужие клоны); для архивной ВКР обычно не нужно.
- Все удалённые PDF сохранены в `removed-pdfs-backup.zip` — ничего не потеряно.
- В git намеренно **оставлены 5 PDF-исходников**, без которых не соберётся диссертация:
  `Dissertation/images/signed.pdf` (подписанный титульник), `images/pd_fear.pdf`,
  `images/table_games_avg_pd.pdf`, `Presentation/images/implementation.pdf`,
  `Styles/img/repeated/bos_fear.pdf` (векторные рисунки). Убрать вообще все PDF нельзя —
  сломается сборка.
