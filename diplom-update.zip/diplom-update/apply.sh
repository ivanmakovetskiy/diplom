#!/usr/bin/env bash
# Applies the repository formatting update (README RU/EN, cleanup, CI) to a
# local clone of https://github.com/ivanmakovetskiy/diplom
#
# Usage (from anywhere inside the clone):
#   bash apply.sh            # apply + stage changes, then review and commit yourself
#   bash apply.sh --commit   # apply + stage + create the commit (you still push yourself)
set -euo pipefail

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="$(git -C "$PKG_DIR" rev-parse --show-toplevel 2>/dev/null || true)"
if [ -z "${REPO}" ]; then
  echo "ERROR: this package must be unpacked INSIDE your clone of the diplom repo." >&2
  exit 1
fi
REMOTE="$(git -C "$REPO" remote get-url origin 2>/dev/null || echo none)"
case "$REMOTE" in
  *ivanmakovetskiy/diplom*) : ;;
  *) echo "WARNING: origin is '$REMOTE', expected ivanmakovetskiy/diplom."
     echo "Re-run with FORCE=1 if this is intentional."
     [ "${FORCE:-0}" = "1" ] || exit 1 ;;
esac
cd "$REPO"
echo "Repo: $REPO"

# 1) Copy new / modified files
echo "Copying updated files..."
(cd "$PKG_DIR/files" && find . -type f -print0 | while IFS= read -r -d '' f; do
  mkdir -p "$REPO/$(dirname "$f")"
  cp "$PKG_DIR/files/$f" "$REPO/$f"
  echo "  + $f"
done)

# 2) Delete build artifacts, Zone.Identifier junk and generated PDFs
echo "Removing junk files..."
while IFS= read -r f; do
  [ -n "$f" ] || continue
  git rm -q --ignore-unmatch -- "$f" 2>/dev/null || rm -f -- "$f"
done <<'DELETE_LIST'
Dissertation/acronyms.aux
Dissertation/annotation.aux
Dissertation/appendix.aux
Dissertation/conclusion.aux
Dissertation/contents.aux
Dissertation/dictionary.aux
Dissertation/dissertation.log
Dissertation/images/drawing.pdf
Dissertation/images/titlo.pdf
Dissertation/images/titlo2.pdf
Dissertation/introduction.aux
Dissertation/part1.aux
Dissertation/part2.aux
Dissertation/part3.aux
Dissertation/references.aux
Dissertation/texput.log
Dissertation/title.aux
Documents/Def_positions.pdf
Documents/GOST 2.105-95.pdf
Documents/GOST 7.1-2003.pdf
Documents/GOST 7.80-2000.pdf
Documents/GOST R 7.0.11-2011.pdf
Documents/GOST R 7.0.5-2008.pdf
"Styles/img/ablation/a_dictator_emotion_prompt_coplayer_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_coplayer_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_coplayer_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_external_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_external_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_external_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_simple_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_simple_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotion_prompt_simple_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotions_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_emotions_by_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_dictator_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_proposer_ultimatum_emotions_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_proposer_ultimatum_emotions_by_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_proposer_ultimatum_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_responder_ultimatum_emotions_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_responder_ultimatum_emotions_by_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_responder_ultimatum_emotions_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_coplayer_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_coplayer_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_coplayer_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_external_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_external_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_external_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_simple_by_run.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_simple_modified_prompts.png\357\200\272Zone.Identifier"
"Styles/img/ablation/a_ultimatum_emotion_prompt_simple_temp.png\357\200\272Zone.Identifier"
"Styles/img/ablation/mod_prompt_legend.png\357\200\272Zone.Identifier"
"Styles/img/ablation/runs_legend.png\357\200\272Zone.Identifier"
"Styles/img/ablation/temp_legend.png\357\200\272Zone.Identifier"
"Styles/img/arch/public_goods_emotion.png\357\200\272Zone.Identifier"
"Styles/img/division_pipe_extended.png\357\200\272Zone.Identifier"
"Styles/img/ethics/ethics_legend.png\357\200\272Zone.Identifier"
"Styles/img/ethics/explicit_ethics_high.png\357\200\272Zone.Identifier"
"Styles/img/ethics/explicit_ethics_low.png\357\200\272Zone.Identifier"
"Styles/img/ethics/implicit_ethics_bad.png\357\200\272Zone.Identifier"
"Styles/img/ethics/implicit_ethics_good.png\357\200\272Zone.Identifier"
"Styles/img/ethics/implicit_ethics_overall.png\357\200\272Zone.Identifier"
"Styles/img/ethics/stereotype.png\357\200\272Zone.Identifier"
"Styles/img/general/framework_pipe.png\357\200\272Zone.Identifier"
"Styles/img/payoff_new.png\357\200\272Zone.Identifier"
"Styles/img/public_goods_emotion.jpg\357\200\272Zone.Identifier"
"Styles/img/repeated/BoS_35.jpg\357\200\272Zone.Identifier"
"Styles/img/repeated/BoS_4.jpg\357\200\272Zone.Identifier"
"Styles/img/repeated/PD_35.jpg\357\200\272Zone.Identifier"
"Styles/img/repeated/PD_4.jpg\357\200\272Zone.Identifier"
"Styles/img/repeated/bos_fear.pdf\357\200\272Zone.Identifier"
"Styles/img/repeated/bos_gpt4o.png\357\200\272Zone.Identifier"
"Styles/img/repeated/bos_llama_70b.png\357\200\272Zone.Identifier"
"Styles/img/repeated/bos_openchat.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/BoS_gpt4o.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/BoS_llama_70b.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/BoS_opcha.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/PD_gpt4o.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/PD_llama_70b.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/PD_opcha.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/bos_35.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/bos_4.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/pd_35.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/coops/pd_4.csv.png\357\200\272Zone.Identifier"
"Styles/img/repeated/pd_gpt4o.png\357\200\272Zone.Identifier"
"Styles/img/repeated/pd_llama_70b.png\357\200\272Zone.Identifier"
"Styles/img/repeated/pd_openchat.png\357\200\272Zone.Identifier"
"Styles/img/repeated/table_games_max_bos_p.jpg\357\200\272Zone.Identifier"
"Styles/neurips_2024.sty\357\200\272Zone.Identifier"
"Styles/old/multilingual_cmp.tex\357\200\272Zone.Identifier"
Styles/old/neurips_2024.pdf
"Styles/old/neurips_2024.pdf\357\200\272Zone.Identifier"
"Styles/old/neurips_example.tex\357\200\272Zone.Identifier"
"Styles/old/previous_materials.tex\357\200\272Zone.Identifier"
"Styles/paper.tex\357\200\272Zone.Identifier"
"Styles/references.bib\357\200\272Zone.Identifier"
dissertatino.bbl
dissertatino.blg
dissertation.aux
dissertation.bcf
dissertation.blg
dissertation.fdb_latexmk
dissertation.fls
dissertation.ilg
dissertation.log
dissertation.nlo
dissertation.nls
dissertation.out
dissertation.pdf
dissertation.run.xml
dissertation.toc
dissertation.xdv
"images/2a.png\357\200\272Zone.Identifier"
"images/MISIS_logoblock_main_rus_RGB-01.png\357\200\272Zone.Identifier"
"images/download(2).png\357\200\272Zone.Identifier"
"images/framework_overview.svg\357\200\272Zone.Identifier"
images/logod.pdf
"images/pd_fear.pdf\357\200\272Zone.Identifier"
"images/prison.png\357\200\272Zone.Identifier"
images/signed.pdf
"images/signed.pdf\357\200\272Zone.Identifier"
"images/table_games_avg_pd.pdf\357\200\272Zone.Identifier"
"images/tall.png\357\200\272Zone.Identifier"
images/titlo.pdf
images/titlo2.pdf
makovetskiy_review.pdf
pomidor.pdf
pomidor4.pdf
presentation.aux
presentation.bcf
presentation.log
presentation.nav
presentation.out
presentation.pdf
presentation.run.xml
presentation.snm
presentation.toc
presentation_booklet.pdf
presentation_handout.pdf
synopsis.pdf
synopsis_booklet.aux
synopsis_booklet.fdb_latexmk
synopsis_booklet.fls
synopsis_booklet.log
synopsis_booklet.pdf
tikz.aux
tikz.fdb_latexmk
tikz.fls
tikz.log
todo.txt
DELETE_LIST
# Catch anything of the same kind that appeared since the package was made
find . -type f -not -path './.git/*' \( \
  -name '*.aux' -o -name '*.bbl' -o -name '*.bcf' -o -name '*.blg' -o \
  -name '*.fdb_latexmk' -o -name '*.fls' -o -name '*.ilg' -o -name '*.log' -o \
  -name '*.nav' -o -name '*.nlo' -o -name '*.nls' -o -name '*.out' -o \
  -name '*.run.xml' -o -name '*.snm' -o -name '*.toc' -o -name '*.xdv' -o \
  -name '*Zone.Identifier' \) -delete

# 3) Stage everything (excluding this update package itself)
PKG_REL="$(realpath --relative-to="$REPO" "$PKG_DIR" 2>/dev/null || basename "$PKG_DIR")"
if [ "$PKG_REL" = "." ]; then
  printf '/apply.sh\n/APPLY_INSTRUCTIONS.md\n/files/\n' >> .git/info/exclude
else
  grep -qxF "/$PKG_REL/" .git/info/exclude 2>/dev/null || echo "/$PKG_REL/" >> .git/info/exclude
fi
git add -A
echo
git status --short | head -n 40
echo "..."
echo "Staged changes: $(git diff --cached --name-only | wc -l) files"

if [ "${1:-}" = "--commit" ]; then
  git commit -m "Оформление репозитория: README (RU/EN), чистка артефактов сборки, CI для PDF"
  echo
  echo "Committed. Now push it:"
  echo "  git push origin main"
else
  echo
  echo "Review the staged changes, then:"
  echo '  git commit -m "Оформление репозитория: README (RU/EN), чистка артефактов сборки, CI для PDF"'
  echo "  git push origin main"
fi
echo
echo "Optional — nice GitHub About section (needs GitHub CLI):"
cat <<'HINT'
  gh repo edit ivanmakovetskiy/diplom --description "Master's thesis (MISIS, 2024): empathy & emotions in LLMs in game-theoretic decision-making - LaTeX (XeLaTeX+Biber)" --add-topic latex,masters-thesis,llm,large-language-models,game-theory,empathy,ai-alignment,decision-making,misis,xelatex
HINT
